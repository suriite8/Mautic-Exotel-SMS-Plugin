<?php

/*
 * @copyright   2016 Mautic Contributors. All rights reserved
 * @author      Mautic
 *
 * @link        http://mautic.org
 *
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

return [
    'services' => [
        'events' => [
            'mautic.exotel.sms.campaignbundle.subscriber' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\EventListener\CampaignSubscriber',
                'arguments' => [
                    'mautic.helper.integration',
                    'mautic.exotel.sms.model.sms',
                ],
            ],
            'mautic.exotel.sms.mauticexotelsmsbundle.subscriber' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\EventListener\SmsSubscriber',
                'arguments' => [
                    'mautic.core.model.auditlog',
                    'mautic.page.model.trackable',
                    'mautic.page.helper.token',
                    'mautic.asset.helper.token',
                ],
            ],
            'mautic.exotel.sms.channel.subscriber' => [
                'class'     => \MauticPlugin\MauticExotelSmsBundle\EventListener\ChannelSubscriber::class,
                'arguments' => [
                    'mautic.helper.integration',
                ],
            ],
            'mautic.exotel.sms.message_queue.subscriber' => [
                'class'     => \MauticPlugin\MauticExotelSmsBundle\EventListener\MessageQueueSubscriber::class,
                'arguments' => [
                    'mautic.exotel.sms.model.sms',
                ],
            ],
            'mautic.exotel.sms.stats.subscriber' => [
                'class'     => \MauticPlugin\MauticExotelSmsBundle\EventListener\StatsSubscriber::class,
                'arguments' => [
                    'doctrine.orm.entity_manager',
                ],
            ],
        ],
        'forms' => [
            'mautic.exotel.form.type.sms' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\Form\Type\SmsType',
                'arguments' => 'mautic.factory',
                'alias'     => 'exotelsms',
            ],
            'mautic.exotel.form.type.exotelsmsconfig' => [
                'class' => 'MauticPlugin\MauticExotelSmsBundle\Form\Type\ConfigType',
                'alias' => 'exotelsmsconfig',
            ],
            'mautic.exotel.form.type.exotelsmssend_list' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\Form\Type\SmsSendType',
                'arguments' => 'router',
                'alias'     => 'exotelsmssend_list',
            ],
            'mautic.exotel.form.type.exotelsmssms_list' => [
                'class' => 'MauticPlugin\MauticExotelSmsBundle\Form\Type\SmsListType',
                'alias' => 'exotelsmssms_list',
            ],
        ],
        'helpers' => [
            'mautic.exotel.helper.sms' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\Helper\SmsHelper',
                'arguments' => [
                    'doctrine.orm.entity_manager',
                    'mautic.lead.model.lead',
                    'mautic.helper.phone_number',
                    'mautic.exotel.sms.model.sms',
                    'mautic.helper.integration',
                ],
                'alias' => 'exotelsms_helper',
            ],
        ],
        'other' => [
            'mautic.exotel.sms.api' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\Api\ExotelApi',
                'arguments' => [
                    'mautic.page.model.trackable',
                    'mautic.helper.phone_number',
                    'mautic.helper.integration',
                    'monolog.logger.mautic',
                ],
                'alias' => 'exotelsms_api',
            ],
        ],
        'models' => [
            'mautic.exotel.sms.model.sms' => [
                'class'     => 'MauticPlugin\MauticExotelSmsBundle\Model\SmsModel',
                'arguments' => [
                    'mautic.page.model.trackable',
                    'mautic.lead.model.lead',
                    'mautic.channel.model.queue',
                    'mautic.exotel.sms.api',
                ],
            ],
        ],
    ],
    'routes' => [
        'main' => [
            'mautic_sms_index' => [
                'path'       => '/exotelsms/{page}',
                'controller' => 'MauticExotelSmsBundle:Sms:index',
            ],
            'mautic_sms_action' => [
                'path'       => '/exotelsms/{objectAction}/{objectId}',
                'controller' => 'MauticExotelSmsBundle:Sms:execute',
            ],
            'mautic_sms_contacts' => [
                'path'       => '/exotelsms/view/{objectId}/contact/{page}',
                'controller' => 'MauticExotelSmsBundle:Sms:contacts',
            ],
        ],
        'public' => [
            'mautic_receive_sms' => [
                'path'       => '/exotelsms/receive',
                'controller' => 'MauticExotelSmsBundle:Api\SmsApi:receive',
            ],
        ],
        'api' => [
            'mautic_api_smsesstandard' => [
                'standard_entity' => true,
                'name'            => 'smses',
                'path'            => '/exotelsmses',
                'controller'      => 'MauticExotelSmsBundle:Api\SmsApi',
            ],
        ],
    ],
    'menu' => [
        'main' => [
            'items' => [
                'mautic.sms.smses' => [
                    'route'  => 'mautic_sms_index',
                    'access' => ['sms:smses:viewown', 'sms:smses:viewother'],
                    'parent' => 'mautic.core.channels',
                    'checks' => [
                        'integration' => [
                            'Exotel' => [
                                'enabled' => true,
                            ],
                        ],
                    ],
                    'priority' => 70,
                ],
            ],
        ],
    ],
    'parameters' => [
        'sms_enabled'              => false,
        'sms_username'             => null,
        'sms_password'             => null,
        'sms_sending_phone_number' => null,
        'sms_frequency_number'     => null,
        'sms_frequency_time'       => null,
    ],
];
